"""Add the shared runtime boundary to the immutable deployed Control engine."""
from .runtime_enrollment import attach_runtime_enrollment
from .runtime_provider import DeployedRuntimeProvider


def factory():
    from .runtime_maintenance import factory as frozen_factory
    app = frozen_factory()
    from .cli_auth_modes import install as install_auth_modes
    install_auth_modes(app)
    attach_runtime_enrollment(app, app.state.store, DeployedRuntimeProvider(app, app.state.store))
    from .runtime_protocol import install
    install(app)
    return app
