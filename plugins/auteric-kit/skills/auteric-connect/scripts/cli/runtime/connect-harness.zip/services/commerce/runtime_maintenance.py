"""Installation-scoped operations around the unchanged deployed enforcement engine.

The owner provisions a renewable service identity; it cannot change policies,
enable capabilities, register mappings or execute customer transactions.
"""
import json
import os
import secrets
import time

from fastapi import Depends, HTTPException, Request
from pydantic import BaseModel, ConfigDict

from .storage import digest

MVP = {'search_products', 'get_product', 'create_cart', 'get_cart', 'add_to_cart'}
LIFETIME = 86400


class Provision(BaseModel):
    model_config = ConfigDict(extra='forbid')
    installation_id: str
    product_id: str
    query: str


def install(app):
    state, dbs = app.state, app.state.store
    domain = os.environ['AUTERIC_PERMANENT_RUNTIME_DOMAIN']
    with dbs.db() as db:
        db.execute('''CREATE TABLE IF NOT EXISTS runtime_maintenance_credentials (
            token_hash TEXT PRIMARY KEY, store_id TEXT NOT NULL, installation_id TEXT NOT NULL,
            actor_id TEXT NOT NULL, product_id TEXT NOT NULL, query TEXT NOT NULL,
            issued_at REAL NOT NULL, expires_at REAL NOT NULL, binding_hash TEXT NOT NULL)''')

    root = '/api/commerce/stores/{store_id}/runtime-maintenance'

    def installation(store_id, installation_id):
        store = state.store_row(store_id)
        if store['domain'] != domain or store['environment'] != 'staging':
            raise HTTPException(403, 'Permanent preview runtime scope mismatch')
        with dbs.db() as db:
            row = db.execute('SELECT * FROM installations WHERE id=? AND store_id=? AND revoked_at IS NULL',
                             (installation_id, store_id)).fetchone()
        if not row:
            raise HTTPException(403, 'Installation unavailable')
        binding = json.loads(row['trust_binding'])
        if set(binding.get('sidecar', {}).get('profiles', {})) != MVP:
            raise HTTPException(403, 'Maintenance is limited to the reviewed five operations')
        return store, digest(row['trust_binding'])

    def service(request: Request, store_id: str):
        token = request.headers.get('authorization', '').removeprefix('Bearer ')
        with dbs.db() as db:
            row = db.execute('SELECT * FROM runtime_maintenance_credentials WHERE token_hash=? AND store_id=? AND expires_at>?',
                             (digest(token), store_id, time.time())).fetchone()
            actor = db.execute('SELECT * FROM users WHERE id=?', (row['actor_id'],)).fetchone() if row else None
        if not row or not actor:
            raise HTTPException(401, 'Service identity expired or revoked')
        store, binding_hash = installation(store_id, row['installation_id'])
        if row['binding_hash'] != binding_hash:
            raise HTTPException(403, 'Reviewed installation mapping changed')
        if actor['org'] != store['org']:
            raise HTTPException(403, 'Service owner changed')
        return dict(row), dict(actor), store

    def issue(store_id, spec, actor_id):
        token = secrets.token_urlsafe(40)
        now = time.time()
        _store, binding_hash = installation(store_id, spec['installation_id'])
        with dbs.db() as db:
            db.execute('DELETE FROM runtime_maintenance_credentials WHERE expires_at<?', (now,))
            db.execute('INSERT INTO runtime_maintenance_credentials VALUES(?,?,?,?,?,?,?,?,?)',
                       (digest(token), store_id, spec['installation_id'], actor_id,
                        spec['product_id'], spec['query'], now, now + LIFETIME, binding_hash))
        return {'token': token, 'expires_at': now + LIFETIME, 'installation_id': spec['installation_id']}

    @app.post(root + '/credential')
    def provision(store_id: str, body: Provision, actor=Depends(state.user_dependency)):
        state.owned(store_id, actor)
        installation(store_id, body.installation_id)
        # A real passed receipt binds the service's product and exact installation.
        with dbs.db() as db:
            rows = db.execute("SELECT body FROM connection_runs WHERE store=? AND state='passed' ORDER BY updated DESC", (store_id,)).fetchall()
        if not any((r := json.loads(row['body'])).get('installation_id') == body.installation_id
                   and r.get('product_id') == body.product_id for row in rows):
            raise HTTPException(409, 'Provisioning requires a passed deployed connection test for the selected product')
        return issue(store_id, body.model_dump(), actor['id'])

    @app.post(root + '/rotate')
    def rotate(store_id: str, identity=Depends(service)):
        spec, actor, _store = identity
        # Keep the current token valid until its original deadline so saving the
        # replacement in Secrets Manager can fail safely and be retried.
        return issue(store_id, spec, actor['id'])

    @app.get(root + '/config')
    async def config(store_id: str, identity=Depends(service)):
        spec, actor, store = identity
        # The existing routing binding also expires. Refresh it by a real
        # external HTTPS comparison, never by updating its timestamp ourselves.
        if not store.get('verified') or store['verified'] < time.time() - 3600:
            verify = next(route.endpoint for route in app.routes if getattr(route, 'path', '') ==
                          '/api/commerce/stores/{store_id}/verify')
            await verify(store_id, actor)
        return state.sidecar_config(store_id, spec['installation_id'], actor)

    @app.post(root + '/renew-evidence')
    async def renew(store_id: str, identity=Depends(service)):
        spec, actor, store = identity
        if not store['agent_access_enabled']:
            raise HTTPException(403, 'Agent access is disabled; maintenance cannot enable it')
        with dbs.db() as db:
            controls = db.execute('SELECT operation,enabled FROM capability_policies WHERE store_id=?', (store_id,)).fetchall()
            running = db.execute("SELECT id FROM connection_runs WHERE store=? AND state IN ('running','uncertain')", (store_id,)).fetchone()
        if running:
            raise HTTPException(409, 'A verification run is active or uncertain; inspect it before another mutation')
        if any(row['operation'] in MVP and not row['enabled'] for row in controls):
            raise HTTPException(403, 'Capability disabled by owner; maintenance cannot enable it')
        # Invoke existing authoritative Connection Test and safety probes. Never
        # extend evidence timestamps or mint a verification result locally.
        from .connection_runs import ConnectionInput
        endpoint = next(route.endpoint for route in app.routes if getattr(route, 'path', '') ==
                        '/api/commerce/stores/{store_id}/test-transaction')
        report = await endpoint(store_id, ConnectionInput(bootstrap_sidecar=True,
                                product_id=spec['product_id'], query=spec['query']), False, actor)
        if report['state'] == 'passed':
            publish = next(route.endpoint for route in app.routes if getattr(route, 'path', '') ==
                           '/api/commerce/stores/{store_id}/connection-tests/{run_id}/publish-evidence')
            report = await publish(store_id, report['run_id'], actor)
        return report


def factory():
    from .app import factory as deployed_factory
    app = deployed_factory()
    install(app)
    from .native_ucp_wire import install as install_wire
    install_wire(app)
    return app
