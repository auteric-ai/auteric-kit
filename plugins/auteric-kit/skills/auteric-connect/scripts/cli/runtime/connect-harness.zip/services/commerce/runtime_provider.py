"""Generic installation orchestration using the existing deployed Connection Test.

This provider does not implement authorization, tests, activation or evidence.
The pinned engine owns those decisions and their durable receipts.
"""
import json
import time

from fastapi import HTTPException

from .runtime_enrollment import PROTOCOL, mapping_digest
from .storage import digest, encode
from .transports.native_http import contracts

MVP = {'search_products', 'get_product', 'create_cart', 'get_cart', 'add_to_cart'}


class DeployedRuntimeProvider:
    def __init__(self, app, dbs):
        self.app, self.state, self.dbs = app, app.state, dbs
        with dbs.db() as db:
            db.execute('CREATE TABLE IF NOT EXISTS runtime_domain_checks (installation_id TEXT PRIMARY KEY, document_digest TEXT NOT NULL)')

    def endpoint(self, path):
        return next(route.endpoint for route in self.app.routes if getattr(route, 'path', '') == path)

    def compatibility(self):
        from .connection_runs import ConnectionInput
        available = (callable(getattr(self.state, 'sidecar_config', None))
                     and callable(getattr(self.state, 'execute_sidecar_verification', None))
                     and 'bootstrap_sidecar' in ConnectionInput.model_fields
                     and getattr(getattr(self.state,'runtime_state',None),'cipher',None) is not None)
        return {'protocol': PROTOCOL, 'available': available,
                'registry_digest': contracts().REGISTRY_DIGEST,
                'engine_profile': 'frozen-rc7/v1', 'environments': ['dev', 'sandbox', 'staging', 'production'],
                'operations': sorted(MVP), 'binding_kinds': ['auteric-bridge-mapping/v1','auteric-module-binding/v1'], 'runtime_state_protocol':'auteric-runtime-state/v1'}

    def validate_enrollment(self, store, installation, mapping):
        if store['environment'] not in self.compatibility()['environments']:
            raise HTTPException(409,'The pinned deployed bootstrap supports dev, sandbox, staging and production')
        if {op['operation'] for op in mapping['operations']} != MVP:
            raise HTTPException(409,'This qualified release requires the five catalog/cart operations')
        binding = json.loads(installation['trust_binding'])
        if (binding.get('native_runtime',{}).get('binding_digest') != mapping_digest(mapping)
                or set(binding.get('sidecar',{}).get('profiles',{})) != MVP):
            raise HTTPException(409,'Register the exact shared-runtime binding before enrollment')
        if mapping.get('schema') == 'auteric-module-binding/v1' and any(p.get('mapping_fingerprint') != mapping['adapter_fingerprint'] for p in binding['sidecar']['profiles'].values()):
            raise HTTPException(409,'Module profile fingerprint differs from adapter')

    def actor(self, store, installation):
        with self.dbs.db() as db:
            row = db.execute('SELECT users.* FROM users JOIN runtime_enrollment_owners ON users.id=runtime_enrollment_owners.actor_id WHERE runtime_enrollment_owners.installation_id=?', (installation['id'],)).fetchone()
        if not row or row['org'] != store['org']:
            raise HTTPException(403, 'Enrollment owner changed or is unavailable')
        return dict(row)

    def bootstrap_allowed(self, store, installation):
        if not store.get('policy_reviewed_at'):
            return False
        with self.dbs.db() as db:
            prior = db.execute("SELECT 1 FROM runtime_enrollment_owners WHERE installation_id=? AND activated IS NOT NULL", (installation['id'],)).fetchone()
        # Once activated, an owner disable must never be undone by maintenance.
        return not prior

    async def config(self, store, installation, mapping):
        actor = self.actor(store, installation)
        sidecar = self.state.sidecar_config(store['id'], installation['id'], actor)
        expected = mapping_digest(mapping)
        registration = json.loads(installation['trust_binding'])
        if registration.get('native_runtime', {}).get('binding_digest') != expected:
            raise HTTPException(409, 'Runtime mapping does not match reviewed installation')
        operations = {op['operation'] for op in mapping['operations']}
        if operations != MVP or set(sidecar['integration']['profiles']) != operations:
            raise HTTPException(409, 'This qualified bootstrap requires the five catalog/cart operations')
        policy = sidecar['operational']['policy']
        # A stable five-minute issue bucket avoids restarting both processes on
        # every read. Evidence deadlines still come from the real test receipt.
        lifetime = int(policy['expires_at'] - policy['issued_at'])
        policy['issued_at'] = int(policy['issued_at'] // 300) * 300
        policy['expires_at'] = policy['issued_at'] + lifetime
        policy['fingerprint'] = 'sha256:' + digest(encode({k:v for k,v in policy.items() if k != 'fingerprint'}))
        deadlines = [policy['expires_at']]
        profiles = sidecar['integration']['profiles']
        for profile in profiles.values():
            if profile['enabled']:
                deadlines.append(profile['verification']['expires_at'])
        with self.dbs.db() as db:
            job = db.execute('SELECT run_id,state,body FROM runtime_verification_jobs WHERE installation_id=?', (installation['id'],)).fetchone()
        with self.dbs.db() as db:
            domain = db.execute('SELECT document_digest FROM runtime_domain_checks WHERE installation_id=?', (installation['id'],)).fetchone()
        discovery = self.endpoint('/api/commerce/stores/{store_id}/discovery')(store['id'], actor)['document']
        enabled = all(profile['enabled'] for profile in profiles.values())
        return {'schema': 'auteric-runtime-bundle/v1', 'engine_profile': 'frozen-rc7/v1',
                'installation_id': installation['id'], 'mapping_digest': expected, 'mapping': mapping,
                'runtime_state_protocol':'auteric-runtime-state/v1', 'sidecar': sidecar, 'expires_at': min(deadlines), 'discovery': encode(discovery),
                'bootstrap': not enabled, 'verification_required': not enabled,
                'verification_state': dict(job) if job else None,
                'domain_refresh_required': not store['verified'] or store['verified'] < time.time() - 3000 or not domain or domain['document_digest'] != digest(encode(discovery))}

    async def refresh_domain(self, store, installation):
        actor = self.actor(store, installation)
        result = await self.endpoint('/api/commerce/stores/{store_id}/verify')(store['id'], actor)
        document = self.endpoint('/api/commerce/stores/{store_id}/discovery')(store['id'], actor)['document']
        with self.dbs.db() as db:
            db.execute('INSERT INTO runtime_domain_checks VALUES(?,?) ON CONFLICT(installation_id) DO UPDATE SET document_digest=excluded.document_digest', (installation['id'],digest(encode(document))))
        return result

    async def verify(self, store, installation, run_id):
        from .connection_runs import ConnectionInput
        actor = self.actor(store, installation)
        if not store.get('policy_reviewed_at'):
            raise HTTPException(409, 'A reviewed installation is required')
        # Product selection is a live, exact-scope read. No remembered IDs,
        # inventory snapshots or customer carts enter the test.
        selection = {'store_id': store['id'], 'installation_id': installation['id'],
                     'actor': actor['id'], 'run_id': run_id, 'binding': self.state.connection_binding(store['id'])}
        catalog = await self.state.execute_sidecar_verification(selection, 'search_products',
                    {'query': ' ', 'limit': 20}, run_id + ':catalog-selection')
        if catalog.get('state') != 'executed':
            return {'run_id': run_id, 'state': 'failed', 'reason': 'Live catalog selection failed'}
        products = catalog.get('result', {}).get('results', [])
        product = next((p for p in products if any(v.get('available') is True for v in p.get('variants', []))), None)
        if not product:
            return {'run_id': run_id, 'state': 'failed', 'reason': 'No sellable test product'}
        start = self.endpoint('/api/commerce/stores/{store_id}/test-transaction')
        report = await start(store['id'], ConnectionInput(bootstrap_sidecar=True,
                            product_id=product['product_id'], query=product['title']), False, actor)
        if report['state'] == 'passed' and report.get('activation', {}).get('agent_access_enabled'):
            publish = self.endpoint('/api/commerce/stores/{store_id}/connection-tests/{run_id}/publish-evidence')
            report = await publish(store['id'], report['run_id'], actor)
        result = report['state'] if report['state'] in {'passed', 'uncertain'} else 'failed'
        if result == 'passed' and not report.get('activation', {}).get('agent_access_enabled'):
            result = 'failed'
        return {'run_id': run_id, 'state': result, 'connection_run_id': report['run_id'],
                'product_id': product['product_id'], 'payment_completed': False}
