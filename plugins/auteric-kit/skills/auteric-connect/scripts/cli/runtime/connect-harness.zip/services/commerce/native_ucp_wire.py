"""Store-scoped wire adapter after the frozen Gateway has authorized/executed.

The pinned public UCP encoder predates MEP/1 catalog response objects. Adapt
only this preview's catalog results to its existing wire encoder. No action,
policy, identity, proof, replay or mutation logic is replaced.
"""
import os
from contextvars import ContextVar
from decimal import Decimal

_SELECTED = ContextVar('native_ucp_wire_selected', default=False)


def product(value):
    if 'product_id' not in value:
        return value
    variants = value['variants']
    if not variants:
        raise ValueError('Authoritative variants required')
    currency = variants[0]['price']['currency']
    mapped = []
    for variant in variants:
        money = variant['price']
        if money['currency'] != currency or type(money['amount_minor']) is not int:
            raise ValueError('Inconsistent catalog money')
        mapped.append({'id': variant['variant_id'], 'title': value['title'],
                       'price': Decimal(money['amount_minor']) / 100,
                       'availability': 'in_stock' if variant['available'] else 'out_of_stock'})
    return {'id': value['product_id'], 'title': value['title'],
            'description': value.get('description', ''), 'currency': currency,
            'price': mapped[0]['price'], 'variants': mapped}


def normalize(operation, result):
    if operation == 'search_products' and isinstance(result, dict) and 'results' in result:
        return [product(p) for p in result['results']]
    if operation == 'get_product' and isinstance(result, dict):
        return product(result)
    if operation == 'lookup_products':
        return {**result, 'products': [product(p) for p in result['products']]}
    return result


def install(app):
    from . import gateway, ucp_mcp
    from .ucp import encode_response
    store_id = os.environ['AUTERIC_PERMANENT_RUNTIME_STORE_ID']
    domain = os.environ['AUTERIC_PERMANENT_RUNTIME_DOMAIN']
    store = app.state.store_row(store_id)
    if store['domain'] != domain or store['environment'] != 'staging':
        raise ValueError('Wire adapter is limited to the permanent preview')

    def encode(operation, result, **kwargs):
        return encode_response(operation, normalize(operation, result) if _SELECTED.get() else result, **kwargs)

    # These are the two existing protocol output boundaries, after execute_action.
    gateway.encode_response = ucp_mcp.encode_response = encode

    @app.middleware('http')
    async def scope(request, call_next):
        selected = request.url.path == f'/ucp/{store_id}/mcp' or \
                   request.url.path.startswith(f'/agent-commerce/{domain}/')
        token = _SELECTED.set(selected)
        try:
            return await call_next(request)
        finally:
            _SELECTED.reset(token)


def mcp_factory():
    from .mcp_server import create_mcp_app
    app = create_mcp_app(os.environ.get('DATABASE_URL') or os.environ.get('AUTERIC_COMMERCE_DATABASE'),
                         os.environ['AUTERIC_COMMERCE_PUBLIC_URL'])
    install(app)
    return app
