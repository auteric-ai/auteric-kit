"""Project canonical catalog results at the existing post-enforcement boundary."""


def install(app):
    from . import gateway, ucp_mcp, ucp
    from .mep_ucp_catalog import is_mep_catalog, encode_catalog
    legacy = ucp.encode_response

    def encode(operation, result, **kwargs):
        if is_mep_catalog(operation, result):
            return encode_catalog(operation, result, '1.0.0')
        return legacy(operation, result, **kwargs)

    gateway.encode_response = ucp_mcp.encode_response = encode


def mcp_factory():
    from .native_ucp_wire import mcp_factory as frozen_factory
    app = frozen_factory()
    install(app)
    return app
