"""Installation-scoped durable runtime state in Auteric, never the merchant DB.

The frozen Sidecar still authenticates/validates every execution. This service
implements its existing store interfaces; it grants no commerce authorization.
"""
import base64
import hashlib
import json
import os
import time
from cryptography.fernet import Fernet, MultiFernet
from fastapi import HTTPException, Request
from pydantic import BaseModel, ConfigDict, Field
from .storage import digest, encode

PROTOCOL='auteric-runtime-state/v1'

class StateInput(BaseModel):
    model_config=ConfigDict(extra='forbid')
    operation: str = Field(max_length=64)
    arguments: list = Field(default_factory=list, max_length=8)

class RuntimeState:
    def __init__(self,dbs,cipher):
        self.dbs,self.cipher=dbs,cipher
        with dbs.db() as db:
            if getattr(dbs,'postgres',False):db.execute("SELECT pg_advisory_xact_lock(hashtext('auteric-runtime-state-v1'))")
            db.execute('''CREATE TABLE IF NOT EXISTS runtime_execution_state (installation TEXT NOT NULL, action TEXT NOT NULL, request_hash TEXT NOT NULL, operation TEXT NOT NULL, status TEXT NOT NULL, claim TEXT NOT NULL, result TEXT, created DOUBLE PRECISION NOT NULL, updated DOUBLE PRECISION NOT NULL, PRIMARY KEY(installation,action))''')
            db.execute('CREATE TABLE IF NOT EXISTS runtime_nonce_state (installation TEXT NOT NULL, nonce TEXT NOT NULL, expires DOUBLE PRECISION NOT NULL, PRIMARY KEY(installation,nonce))')
            db.execute('CREATE TABLE IF NOT EXISTS runtime_bridge_state (installation TEXT NOT NULL, kind TEXT NOT NULL, key TEXT NOT NULL, body TEXT NOT NULL, PRIMARY KEY(installation,kind,key))')
            db.execute('CREATE TABLE IF NOT EXISTS runtime_audit_state (installation TEXT NOT NULL, event TEXT NOT NULL, body TEXT NOT NULL, PRIMARY KEY(installation,event))')
    def seal(self,value):
        if self.cipher is None: raise HTTPException(503,'Runtime state encryption unavailable')
        return self.cipher.encrypt(encode(value).encode()).decode()
    def open(self,value):
        if self.cipher is None: raise HTTPException(503,'Runtime state encryption unavailable')
        return json.loads(self.cipher.decrypt(value.encode()))
    def call(self,iid,op,args):
        if self.cipher is None: raise HTTPException(503,'Runtime state encryption unavailable')
        now=time.time()
        if op=='ready':
            if self.cipher is None: raise HTTPException(503,'Runtime state encryption unavailable')
            with self.dbs.db() as db: db.execute('SELECT 1 FROM runtime_execution_state LIMIT 1').fetchone()
            return {'ready':True,'protocol':PROTOCOL}
        if op=='nonce':
            nonce,ttl=args;ttl=max(60,min(float(ttl),300));nonce=digest(str(nonce))
            with self.dbs.db() as db:
                db.execute('DELETE FROM runtime_nonce_state WHERE installation=? AND expires<?',(iid,now))
                row=db.execute('INSERT INTO runtime_nonce_state VALUES(?,?,?) ON CONFLICT DO NOTHING RETURNING nonce',(iid,nonce,now+ttl)).fetchone()
            return {'fresh':bool(row)}
        if op=='reserve':
            action,request_hash,operation,claim=args
            with self.dbs.db() as db:
                inserted=db.execute("INSERT INTO runtime_execution_state VALUES(?,?,?,?,'executing',?,NULL,?,?) ON CONFLICT DO NOTHING RETURNING action",(iid,action,request_hash,operation,claim,now,now)).fetchone()
                row=db.execute('SELECT * FROM runtime_execution_state WHERE installation=? AND action=?',(iid,action)).fetchone()
                if row['request_hash']!=request_hash or row['operation']!=operation: raise HTTPException(409,'IDEMPOTENCY_CONFLICT')
                if not inserted and row['status']!='completed': raise HTTPException(409,'EXECUTION_UNCERTAIN')
            return {'replay':not bool(inserted),'record':self.record(row)}
        if op=='get':
            with self.dbs.db() as db: row=db.execute('SELECT * FROM runtime_execution_state WHERE installation=? AND action=?',(iid,args[0])).fetchone()
            return {'record':self.record(row) if row else None}
        if op in {'complete','uncertain','release'}:
            action,claim=args[:2]
            with self.dbs.db() as db:
                row=db.execute('SELECT * FROM runtime_execution_state WHERE installation=? AND action=?',(iid,action)).fetchone()
                if not row or row['claim']!=claim:raise HTTPException(409,'EXECUTION_CLAIM_MISMATCH')
                if row['status']=='completed':return {'ok':True,'status':'completed'}
                if op=='release':
                    changed=db.execute("DELETE FROM runtime_execution_state WHERE installation=? AND action=? AND claim=? AND status='executing' RETURNING action",(iid,action,claim)).fetchone()
                elif op=='complete':
                    result=self.seal(args[2])
                    changed=db.execute("UPDATE runtime_execution_state SET status='completed',result=?,updated=? WHERE installation=? AND action=? AND claim=? AND status IN ('executing','uncertain') RETURNING action",(result,now,iid,action,claim)).fetchone()
                else:
                    changed=db.execute("UPDATE runtime_execution_state SET status='uncertain',updated=? WHERE installation=? AND action=? AND claim=? AND status IN ('executing','uncertain') RETURNING action",(now,iid,action,claim)).fetchone()
                if not changed:raise HTTPException(409,'EXECUTION_UNCERTAIN')
            return {'ok':True}
        if op=='audit':
            event,body=args
            with self.dbs.db() as db: db.execute('INSERT INTO runtime_audit_state VALUES(?,?,?) ON CONFLICT DO NOTHING',(iid,event,self.seal(body)))
            return {'ok':True}
        if op in {'kv_get','kv_claim','kv_put'}:
            kind,key=args[:2]
            if kind not in {'session','session_claim','id','variant','manager'}:raise HTTPException(400,'Unknown runtime state kind')
            key=digest(encode(key))
            with self.dbs.db() as db:
                if op=='kv_get':
                    row=db.execute('SELECT body FROM runtime_bridge_state WHERE installation=? AND kind=? AND key=?',(iid,kind,key)).fetchone()
                    return {'value':self.open(row['body']) if row else None}
                body=self.seal(args[2])
                if kind=='manager' and op=='kv_put':
                    db.execute('INSERT INTO runtime_bridge_state VALUES(?,?,?,?) ON CONFLICT(installation,kind,key) DO UPDATE SET body=excluded.body',(iid,kind,key,body));return {'changes':1}
                row=db.execute('INSERT INTO runtime_bridge_state VALUES(?,?,?,?) ON CONFLICT DO NOTHING RETURNING key',(iid,kind,key,body)).fetchone()
                return {'changes':int(bool(row))}
        raise HTTPException(400,'Unknown runtime state operation')
    def record(self,row):
        return {'installation_id':row['installation'],'action_id':row['action'],'request_hash':row['request_hash'],'operation':row['operation'],'status':row['status'],'claim':row['claim'],'result':self.open(row['result']) if row['result'] else None,'created_at':row['created'],'updated_at':row['updated']}

def attach_runtime_state(app,dbs,service_auth=None):
    key=os.environ.get('AUTERIC_RUNTIME_STATE_KEY') or os.environ.get('AUTERIC_JOB_ENCRYPTION_KEY')
    if not key and os.environ.get('AUTERIC_EXECUTION_ED25519_SEED'):
        seed=os.environ['AUTERIC_EXECUTION_ED25519_SEED'];raw=base64.urlsafe_b64decode(seed+'='*(-len(seed)%4))
        key=base64.urlsafe_b64encode(hashlib.sha256(b'auteric-runtime-state/v1:'+raw).digest()).decode()
    if not key and getattr(app.state,'development',False):key=base64.urlsafe_b64encode(hashlib.sha256((dbs.database_url+':runtime-state').encode()).digest()).decode()
    previous=[value.strip() for value in os.environ.get('AUTERIC_RUNTIME_STATE_PREVIOUS_KEYS','').split(',') if value.strip()]
    cipher=MultiFernet([Fernet(value.encode()) for value in [key,*previous]]) if key else None
    store=RuntimeState(dbs,cipher)
    app.state.runtime_state=store
    app.state.runtime_state_auth=service_auth
    if any(getattr(route,'path',None)=='/api/commerce/stores/{store_id}/runtime-state/{installation_id}' for route in app.routes):return
    @app.post('/api/commerce/stores/{store_id}/runtime-state/{installation_id}')
    async def call(store_id:str,installation_id:str,request:Request):
        if len(await request.body())>2*1024*1024:raise HTTPException(413,'Runtime state request too large')
        try:body=StateInput.model_validate(await request.json())
        except (ValueError,TypeError):raise HTTPException(422,'Invalid runtime state request') from None
        authenticate=app.state.runtime_state_auth
        if authenticate:
            identity=authenticate(request,store_id)
            if identity[1]['id']!=installation_id:raise HTTPException(403,'Runtime identity installation mismatch')
        elif getattr(app.state,'development',False):
            auth=request.headers.get('authorization','')
            credential=app.state.credential_vault.resolve(auth.removeprefix('Bearer '),'sidecar:'+installation_id,store_id)
            if not auth.startswith('Bearer ') or not credential:raise HTTPException(401,'Runtime identity required')
        else:raise HTTPException(503,'Runtime identity service unavailable')
        if body.operation=='reserve':
            with dbs.db() as db:
                inst=db.execute('SELECT trust_binding FROM installations WHERE id=? AND store_id=? AND revoked_at IS NULL',(installation_id,store_id)).fetchone()
            if not inst:raise HTTPException(403,'Installation unavailable')
            profiles=json.loads(inst['trust_binding']).get('sidecar',{}).get('profiles',{})
            if len(body.arguments)!=4 or body.arguments[2] not in profiles:raise HTTPException(403,'Unregistered operation')
        try:return app.state.runtime_state.call(installation_id,body.operation,body.arguments)
        except (ValueError,TypeError,IndexError):raise HTTPException(400,'Invalid runtime state arguments') from None
