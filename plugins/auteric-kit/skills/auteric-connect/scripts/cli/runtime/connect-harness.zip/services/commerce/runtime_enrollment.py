"""Installation orchestration around the frozen engine.

Providers must supply authoritative config, isolated verification and HTTPS domain
verification through supported APIs. Main has no qualified Sidecar bootstrap
provider: preflight returns incompatible and issues no credential in that case.
"""
from __future__ import annotations

import base64
import hashlib
import json
import secrets
import time
from typing import Protocol
from contextvars import ContextVar

from fastapi import Depends, HTTPException, Request
from pydantic import BaseModel, ConfigDict, Field

from .storage import digest, encode, uid

PROTOCOL = "auteric-runtime-enrollment/v1"


class RuntimeProvider(Protocol):
    """No owner session is passed to a background provider."""
    def compatibility(self) -> dict: ...
    async def config(self, store: dict, installation: dict, mapping: dict) -> dict: ...
    async def verify(self, store: dict, installation: dict, run_id: str) -> dict: ...
    async def refresh_domain(self, store: dict, installation: dict) -> dict: ...


class EmptyInput(BaseModel):
    model_config = ConfigDict(extra="forbid")


class EnrollmentInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    installation_id: str = Field(min_length=1, max_length=200)
    mapping_digest: str = Field(pattern=r"^sha256:[0-9a-f]{64}$")
    mapping: dict


def mapping_digest(mapping):
    return "sha256:" + hashlib.sha256(json.dumps(mapping, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()


def attach_runtime_enrollment(app, dbs, provider: RuntimeProvider | None = None):
    state = app.state
    verification_header = ContextVar("runtime_verification_header", default="")

    @app.middleware("http")
    async def verification_context(request, call_next):
        token = verification_header.set(request.headers.get("x-auteric-verification", ""))
        try: return await call_next(request)
        finally: verification_header.reset(token)

    root = "/api/commerce/stores/{store_id}/runtime-enrollment"
    with dbs.db() as db:
        db.execute("""CREATE TABLE IF NOT EXISTS runtime_enrollments (
            installation_id TEXT PRIMARY KEY, store_id TEXT NOT NULL, org TEXT NOT NULL,
            binding_hash TEXT NOT NULL, mapping_digest TEXT NOT NULL, mapping TEXT NOT NULL,
            enrollment_hash TEXT NOT NULL, enrollment_expires DOUBLE PRECISION NOT NULL, exchanged DOUBLE PRECISION,
            revoked DOUBLE PRECISION)""")
        db.execute("""CREATE TABLE IF NOT EXISTS runtime_service_credentials (
            token_hash TEXT PRIMARY KEY, installation_id TEXT NOT NULL,
            issued DOUBLE PRECISION NOT NULL, expires DOUBLE PRECISION NOT NULL)""")
        db.execute("""CREATE TABLE IF NOT EXISTS runtime_verification_jobs (
            installation_id TEXT PRIMARY KEY, run_id TEXT NOT NULL, state TEXT NOT NULL,
            body TEXT NOT NULL, updated DOUBLE PRECISION NOT NULL)""")

    with dbs.db() as db:
        db.execute("CREATE TABLE IF NOT EXISTS runtime_enrollment_owners (installation_id TEXT PRIMARY KEY, actor_id TEXT NOT NULL, activated DOUBLE PRECISION)")
        db.execute("CREATE TABLE IF NOT EXISTS runtime_credential_generations (token_hash TEXT PRIMARY KEY, generation TEXT NOT NULL)")
        db.execute("CREATE TABLE IF NOT EXISTS runtime_enrollment_history (installation_id TEXT NOT NULL, generation TEXT NOT NULL, body TEXT NOT NULL, PRIMARY KEY(installation_id,generation))")
        db.execute("CREATE TABLE IF NOT EXISTS runtime_verification_history (run_id TEXT PRIMARY KEY, installation_id TEXT NOT NULL, state TEXT NOT NULL, body TEXT NOT NULL, updated DOUBLE PRECISION NOT NULL)")
        db.execute("CREATE TABLE IF NOT EXISTS runtime_credential_modes (token_hash TEXT PRIMARY KEY, bootstrap INTEGER NOT NULL)")

    if provider is not None:
        previous_vault = state.credential_vault
        class RuntimeCredentialVault:
            def __getattr__(self, name): return getattr(previous_vault, name)
            def resolve(self, token, kind, store_id=None):
                with dbs.db() as db:
                    row = db.execute("SELECT * FROM runtime_service_credentials WHERE token_hash=?", (digest(token),)).fetchone()
                    mode = db.execute("SELECT bootstrap FROM runtime_credential_modes WHERE token_hash=?", (digest(token),)).fetchone()
                if row and kind.startswith('sidecar:'):
                    if row['expires'] <= time.time() or kind != 'sidecar:' + row['installation_id']:
                        return None
                    try:
                        _store, _inst, enrollment = current(store_id, row['installation_id'])
                        with dbs.db() as db:
                            generation=db.execute('SELECT generation FROM runtime_credential_generations WHERE token_hash=?',(digest(token),)).fetchone()
                        if not generation or generation['generation']!=enrollment['enrollment_hash']: return None
                    except HTTPException: return None
                    if mode and mode['bootstrap']:
                        with dbs.db() as db:
                            scope = db.execute("SELECT 1 FROM sidecar_test_scopes WHERE token_hash=? AND store_id=? AND installation_id=? AND expires_at>?", (digest(verification_header.get()), store_id, row['installation_id'], time.time())).fetchone()
                        if not scope: return None
                return previous_vault.resolve(token, kind, store_id)
        state.credential_vault = RuntimeCredentialVault()

    def compatibility():
        if provider is None:
            return {"protocol": PROTOCOL, "available": False, "reason": "main lacks qualified Sidecar config and isolated bootstrap verification provider"}
        result = provider.compatibility()
        if result.get("protocol") != PROTOCOL or result.get("available") is not True:
            return {"protocol": PROTOCOL, "available": False, "reason": "runtime provider contract incompatible"}
        return result

    def require_provider():
        if not compatibility()["available"]:
            raise HTTPException(409, "runtime_api_incompatible: qualified Sidecar bootstrap provider unavailable")

    @app.get("/api/commerce/runtime-compatibility")
    def readiness():
        return compatibility()

    def installation(store_id, installation_id):
        store = state.store_row(store_id)
        with dbs.db() as db:
            row = db.execute("SELECT * FROM installations WHERE id=? AND store_id=? AND revoked_at IS NULL", (installation_id, store_id)).fetchone()
        if not row or row["environment"] != store["environment"] or row["transport"] != "native_http":
            raise HTTPException(403, "Installation revoked, missing or environment mismatch")
        return store, dict(row)

    def bearer(request):
        auth = request.headers.get("authorization", "")
        if not auth.startswith("Bearer ") or len(auth) < 39:
            raise HTTPException(401, "Runtime service credential required")
        return auth[7:]

    def current(store_id, installation_id):
        store, inst = installation(store_id, installation_id)
        with dbs.db() as db:
            row = db.execute("SELECT * FROM runtime_enrollments WHERE installation_id=? AND store_id=? AND revoked IS NULL", (installation_id, store_id)).fetchone()
        if not row or row["org"] != store["org"] or row["binding_hash"] != digest(inst["trust_binding"]):
            raise HTTPException(403, "Installation owner or binding changed")
        with dbs.db() as db:
            owner = db.execute("SELECT users.org FROM users JOIN runtime_enrollment_owners ON users.id=runtime_enrollment_owners.actor_id WHERE runtime_enrollment_owners.installation_id=?", (installation_id,)).fetchone()
        if not owner or owner['org'] != store['org']:
            raise HTTPException(403, 'Enrollment owner changed or is unavailable')
        return store, inst, dict(row)

    def service(request: Request, store_id: str):
        require_provider()
        with dbs.db() as db:
            row = db.execute("SELECT * FROM runtime_service_credentials WHERE token_hash=? AND expires>?", (digest(bearer(request)), time.time())).fetchone()
        if not row:
            raise HTTPException(401, "Runtime service credential expired or revoked")
        with dbs.db() as db:
            mode = db.execute("SELECT bootstrap FROM runtime_credential_modes WHERE token_hash=?", (row['token_hash'],)).fetchone()
        binding = current(store_id, row['installation_id'])
        with dbs.db() as db:
            generation=db.execute('SELECT generation FROM runtime_credential_generations WHERE token_hash=?',(row['token_hash'],)).fetchone()
        if not generation or generation['generation'] != binding[2]['enrollment_hash']:
            raise HTTPException(403, 'Runtime identity belongs to an earlier enrollment')
        return (*binding, {**dict(row), 'bootstrap': bool(mode and mode['bootstrap'])})

    def issue(installation_id, *, token=None, issued=None, bootstrap=None):
        token = token or secrets.token_urlsafe(40)
        now = time.time() if issued is None else issued
        with dbs.db() as db:
            owner = db.execute("SELECT activated FROM runtime_enrollment_owners WHERE installation_id=?", (installation_id,)).fetchone()
            if bootstrap is None: bootstrap = not owner or not owner['activated']
            expires = now + (1800 if bootstrap else 86400)
            inst = db.execute("SELECT store_id FROM installations WHERE id=?", (installation_id,)).fetchone()
            db.execute("INSERT INTO runtime_service_credentials VALUES(?,?,?,?) ON CONFLICT DO NOTHING", (digest(token), installation_id, now, expires))
            record = db.execute('SELECT enrollment_hash FROM runtime_enrollments WHERE installation_id=?',(installation_id,)).fetchone()
            db.execute('INSERT INTO runtime_credential_generations VALUES(?,?) ON CONFLICT DO NOTHING',(digest(token),record['enrollment_hash']))
            db.execute("INSERT INTO runtime_credential_modes VALUES(?,?) ON CONFLICT DO NOTHING", (digest(token), int(bootstrap)))
            # This identity is scoped again by RuntimeCredentialVault before
            # the frozen Sidecar ingress accepts it. Bootstrap accepts only an
            # exact existing test scope, never ordinary agent transactions.
            db.execute("INSERT INTO credentials(hash,store,kind,created,revoked) VALUES(?,?,?,?,NULL) ON CONFLICT DO NOTHING", (digest(token), inst['store_id'], 'sidecar:' + installation_id, now))
        return {"token": token, "installation_id": installation_id, "expires_at": expires, "enrollment": False, "bootstrap": bootstrap}

    @app.post(root)
    def enroll(store_id: str, body: EnrollmentInput, actor=Depends(state.user_dependency)):
        state.owned(store_id, actor)
        require_provider()
        store, inst = installation(store_id, body.installation_id)
        if len(encode(body.mapping)) > 65536 or mapping_digest(body.mapping) != body.mapping_digest:
            raise HTTPException(422, "Mapping size or digest mismatch")
        # The shared product schema, not a parallel manual output contract.
        from pathlib import Path
        import jsonschema
        name = "module-binding" if body.mapping.get("schema") == "auteric-module-binding/v1" else "bridge-mapping"
        path = Path(__file__).resolve().parents[2] / f"packages/merchant-runtime/schemas/{name}.schema.json"
        try:
            jsonschema.Draft202012Validator(json.loads(path.read_text())).validate(body.mapping)
        except (jsonschema.ValidationError, OSError) as exc:
            raise HTTPException(422, "Mapping schema unavailable or invalid") from exc
        if name == "module-binding":
            from .transports.native_http import contracts
            registry = contracts().OPERATIONS
            selected = [op["operation"] for op in body.mapping["operations"]]
            if len(set(selected)) != len(selected) or any(op["operation"] not in registry or op["side_effect"] != registry[op["operation"]]["side_effect"] for op in body.mapping["operations"]):
                raise HTTPException(422, "Module binding operations or effects mismatch")
        if body.mapping["registry_digest"] != compatibility().get("registry_digest"):
            raise HTTPException(409, "Registry digest incompatible")
        validator = getattr(provider, 'validate_enrollment', None)
        if validator: validator(store,inst,body.mapping)
        with dbs.db() as db:
            db.execute("BEGIN IMMEDIATE")
            if dbs.postgres: db.execute('SELECT id FROM installations WHERE id=? FOR UPDATE',(body.installation_id,)).fetchone()
            existing = db.execute("SELECT * FROM runtime_enrollments WHERE installation_id=?", (body.installation_id,)).fetchone()
            if existing and not existing['revoked']:
                if existing["mapping_digest"] != body.mapping_digest or existing["binding_hash"] != digest(inst["trust_binding"]):
                    raise HTTPException(409, "Mapping drift requires explicit review")
                return {"installation_id": body.installation_id, "status": "deployment_pending", "no_op": True}
            if existing:
                active = db.execute("SELECT 1 FROM runtime_verification_jobs WHERE installation_id=? AND state IN ('running','uncertain')",(body.installation_id,)).fetchone()
                if active: raise HTTPException(409,'Retained unconfirmed verification requires reconciliation before reconnect')
                db.execute('INSERT INTO runtime_enrollment_history VALUES(?,?,?) ON CONFLICT DO NOTHING',(body.installation_id,existing['enrollment_hash'],encode(dict(existing))))
                db.execute('DELETE FROM runtime_enrollments WHERE installation_id=?',(body.installation_id,))
                db.execute('DELETE FROM runtime_verification_jobs WHERE installation_id=?',(body.installation_id,))
            db.execute("INSERT INTO runtime_enrollment_owners VALUES(?,?,NULL) ON CONFLICT(installation_id) DO UPDATE SET actor_id=excluded.actor_id,activated=NULL", (body.installation_id, actor["id"]))
            token = secrets.token_urlsafe(40)
            expires = time.time() + 600
            db.execute("INSERT INTO runtime_enrollments VALUES(?,?,?,?,?,?,?,?,NULL,NULL)",
                       (body.installation_id, store_id, actor["org"], digest(inst["trust_binding"]), body.mapping_digest, encode(body.mapping), digest(token), expires))
        return {"installation_id": body.installation_id, "token": token, "expires_at": expires, "enrollment": True, "status": "deployment_pending"}

    @app.post(root + "/exchange")
    def exchange(store_id: str, request: Request):
        require_provider()
        with dbs.db() as db:
            row = db.execute("SELECT * FROM runtime_enrollments WHERE enrollment_hash=? AND store_id=?", (digest(bearer(request)), store_id)).fetchone()
        if not row or row["exchanged"] or row["enrollment_expires"] <= time.time():
            raise HTTPException(401, "Enrollment consumed or expired")
        current(store_id, row["installation_id"])
        # Compare-and-swap makes the exchange single-use under concurrent workers.
        with dbs.db() as db:
            changed = db.execute("UPDATE runtime_enrollments SET exchanged=? WHERE installation_id=? AND exchanged IS NULL AND revoked IS NULL AND enrollment_expires>?", (time.time(), row["installation_id"], time.time())).rowcount
        if changed != 1:
            raise HTTPException(409, "Enrollment already consumed")
        return exchanged_identity(row, bearer(request), time.time())

    def exchanged_identity(row, enrollment_token, issued):
        from .installations import Installation
        _store, inst = installation(row['store_id'], row['installation_id'])
        _kid, signer = state.native_transport._signing_key(Installation.from_row(inst))
        value = base64.urlsafe_b64encode(signer.sign(('auteric-enrollment/v1:' + row['installation_id'] + ':' + enrollment_token).encode())).decode().rstrip('=')
        # Deterministic recovery preserves the original deadline. It never
        # performs a second enrollment exchange or extends bootstrap authority.
        with dbs.db() as db:
            actual = db.execute("SELECT exchanged FROM runtime_enrollments WHERE installation_id=?", (row['installation_id'],)).fetchone()
        return issue(row['installation_id'], token=value, issued=actual['exchanged'], bootstrap=True)

    @app.get(root + "/exchange-result")
    def exchange_result(store_id: str, request: Request):
        require_provider()
        with dbs.db() as db:
            row = db.execute("SELECT * FROM runtime_enrollments WHERE enrollment_hash=? AND store_id=? AND exchanged IS NOT NULL AND enrollment_expires>?", (digest(bearer(request)),store_id,time.time())).fetchone()
        if not row: raise HTTPException(401, "Exchange recovery expired or unavailable")
        current(store_id,row['installation_id'])
        return exchanged_identity(row,bearer(request),row['exchanged'])

    @app.post(root + "/promote")
    def promote(store_id: str, identity=Depends(service)):
        with dbs.db() as db:
            owner = db.execute("SELECT activated FROM runtime_enrollment_owners WHERE installation_id=?", (identity[1]['id'],)).fetchone()
        if not owner or not owner['activated']: raise HTTPException(409, "Promotion requires an authoritative passed test")
        return issue(identity[1]['id'],bootstrap=False)

    @app.get(root + "/verification")
    def verification_status(store_id: str, identity=Depends(service)):
        with dbs.db() as db:
            row = db.execute("SELECT run_id,state,body FROM runtime_verification_jobs WHERE installation_id=?", (identity[1]['id'],)).fetchone()
        return json.loads(row['body']) if row and row['body'] != '{}' else dict(row) if row else {"state":"absent"}

    @app.get(root + "/config")
    async def config(store_id: str, identity=Depends(service)):
        store, inst, record, _credential = identity
        bundle = await provider.config(store, inst, json.loads(record["mapping"]))
        if bundle.get("installation_id") != inst["id"] or bundle.get("mapping_digest") != record["mapping_digest"]:
            raise HTTPException(409, "Provider configuration binding mismatch")
        return bundle

    @app.post(root + "/rotate")
    def rotate(store_id: str, identity=Depends(service)):
        # Current deadline is unchanged. The caller persists the replacement atomically.
        return issue(identity[1]["id"])

    @app.post(root + "/refresh-domain")
    async def refresh_domain(store_id: str, body: EmptyInput = EmptyInput(), identity=Depends(service)):
        return await provider.refresh_domain(identity[0], identity[1])

    @app.post(root + "/verification")
    async def verify(store_id: str, request: Request, body: EmptyInput = EmptyInput(), identity=Depends(service)):
        store, inst, record, _credential = identity
        if not store["agent_access_enabled"] and not (getattr(provider,"bootstrap_allowed",lambda *_:False)(store,inst)):
            raise HTTPException(403, "Owner disabled agent access; maintenance cannot enable it")
        ops = {op["operation"] for op in json.loads(record["mapping"])["operations"]}
        requested = request.headers.get('idempotency-key', '')
        if requested and (len(requested) > 100 or not requested.replace('-', '').isalnum()):
            raise HTTPException(422, 'Invalid verification request identity')
        run_id = requested or uid()
        with dbs.db() as db:
            db.execute("BEGIN IMMEDIATE")
            if dbs.postgres: db.execute('SELECT id FROM installations WHERE id=? FOR UPDATE',(inst['id'],)).fetchone()
            disabled = db.execute("SELECT operation FROM capability_policies WHERE store_id=? AND enabled=0", (store_id,)).fetchall()
            if ops & {row["operation"] for row in disabled}:
                raise HTTPException(403, "Owner disabled capability")
            active = db.execute("SELECT run_id,state,body FROM runtime_verification_jobs WHERE installation_id=?", (inst["id"],)).fetchone()
            other = db.execute("SELECT id FROM connection_runs WHERE store=? AND state IN ('running','uncertain')", (store_id,)).fetchone()
            if active and requested and active['run_id'] == requested:
                return json.loads(active['body']) if active['body'] != '{}' else {'run_id':requested,'state':active['state']}
            if other or active and active["state"] in {"running", "uncertain"}:
                raise HTTPException(409, "Running or uncertain verification requires reconciliation")
            db.execute("INSERT INTO runtime_verification_jobs VALUES(?,?,?,?,?) ON CONFLICT(installation_id) DO UPDATE SET run_id=excluded.run_id,state=excluded.state,body=excluded.body,updated=excluded.updated", (inst["id"], run_id, "running", "{}", time.time()))
        try:
            report = await provider.verify(store, inst, run_id)
            if report.get("run_id") != run_id or report.get("state") not in {"passed", "failed", "uncertain"}:
                raise ValueError("Provider verification result invalid")
        except Exception:
            report = {"run_id": run_id, "state": "uncertain"}
        with dbs.db() as db:
            db.execute('INSERT INTO runtime_verification_history VALUES(?,?,?,?,?) ON CONFLICT DO NOTHING',(run_id,inst['id'],report['state'],encode(report),time.time()))
            if report['state'] == 'passed':
                db.execute("UPDATE runtime_enrollment_owners SET activated=? WHERE installation_id=?", (time.time(),inst['id']))
            db.execute("UPDATE runtime_verification_jobs SET state=?,body=?,updated=? WHERE installation_id=? AND run_id=?", (report["state"], encode(report), time.time(), inst["id"], run_id))
        return report

    @app.delete(root + "/{installation_id}")
    def revoke(store_id: str, installation_id: str, actor=Depends(state.user_dependency)):
        state.owned(store_id, actor)
        with dbs.db() as db:
            db.execute("UPDATE runtime_enrollments SET revoked=? WHERE installation_id=? AND store_id=?", (time.time(), installation_id, store_id))
        return {"revoked": True, "data_retained": True}

    from .runtime_state import attach_runtime_state
    attach_runtime_state(app,dbs,service)
