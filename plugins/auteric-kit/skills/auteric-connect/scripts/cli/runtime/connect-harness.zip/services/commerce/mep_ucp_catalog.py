"""Versioned catalog projection after enforcement; integer money stays exact.

Legacy connector payloads are handled by ucp.encode_response unchanged. This
adapter does not publish capabilities or turn a five-operation scope into full
UCP cart/checkout support.
"""
from .transports.native_http import contracts


def is_mep_catalog(operation, result):
    if operation == "search_products":
        return isinstance(result, dict) and "results" in result
    if operation == "get_product":
        return isinstance(result, dict) and "product_id" in result
    if operation == "lookup_products" and isinstance(result, dict):
        return any(isinstance(p, dict) and "product_id" in p for p in result.get("products", []))
    return False


def product(value, lookup_ids=None):
    contracts().validate_output("get_product", value)
    variants = value["variants"]
    currencies = {v["price"]["currency"] for v in variants}
    if len(currencies) != 1:
        raise ValueError("Mixed product currencies")
    mapped = []
    for variant in variants:
        out = {"id": variant["variant_id"], "title": variant.get("title", value["title"]),
               "description": {"plain": value.get("description", "")},
               "price": {"amount": variant["price"]["amount_minor"], "currency": variant["price"]["currency"]},
               "availability": {"available": variant["available"]}}
        if lookup_ids is not None:
            correlations = [{"id": item, "match": "exact" if item == variant["variant_id"] else "featured"}
                            for item in lookup_ids if item in {variant["variant_id"], value["product_id"]}]
            if not correlations:
                continue
            out["inputs"] = correlations
        mapped.append(out)
    if not mapped:
        raise ValueError("Product does not resolve the requested identifier")
    prices = [v["price"]["amount"] for v in mapped]
    currency = mapped[0]["price"]["currency"]
    return {"id": value["product_id"], "title": value["title"],
            "description": {"plain": value.get("description", "")}, "variants": mapped,
            "price_range": {"min": {"amount": min(prices), "currency": currency},
                            "max": {"amount": max(prices), "currency": currency}}}


def encode_catalog(operation, result, version):
    if version != "1.0.0":
        raise ValueError("Unknown merchant contract version")
    from .ucp import VERSION, OP_CAP
    metadata = {"version": VERSION, "capabilities": {"dev.ucp.shopping." + OP_CAP[operation]: [{"version": VERSION}]}}
    if operation == "search_products":
        contracts().validate_output(operation, result)
        body = {"products": [product(p) for p in result["results"]]}
        if result["page"].get("has_more"):
            body["next_cursor"] = result["page"]["next_cursor"]
    elif operation == "get_product":
        body = {"product": product(result)}
    elif operation == "lookup_products":
        body = {"products": [product(p, result["ids"]) for p in result["products"]]}
    else:
        raise ValueError("Only catalog projection is qualified for MEP/1")
    return {"ucp": metadata, **body}
