"""Browser/device approval compatibility over the deployed PKCE exchange.

Only start, approval and page rendering change. Login, CSRF, sessions and the
single-use verifier/state-bound poll endpoint remain owned by the existing app.
"""
import re
import secrets
import time
from pathlib import Path
from typing import Literal

from fastapi import Depends, HTTPException, Request
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, ConfigDict, Field

from .storage import digest


class StartInput(BaseModel):
    model_config = ConfigDict(extra='forbid')
    challenge: str = Field(pattern=r'^[A-Za-z0-9_-]{43}$')
    state: str = Field(pattern=r'^[A-Za-z0-9_-]{32,128}$')
    # Older clients omit this field and still expect a pairing code.
    approval_mode: Literal['browser', 'device'] = 'device'


def install(app):
    state, dbs = app.state, app.state.store
    with dbs.db() as db:
        if dbs.postgres:
            db.execute("ALTER TABLE cli_authorizations ADD COLUMN IF NOT EXISTS approval_mode TEXT NOT NULL DEFAULT 'device'")
        elif 'approval_mode' not in {row['name'] for row in db.execute('PRAGMA table_info(cli_authorizations)')}:
            db.execute("ALTER TABLE cli_authorizations ADD COLUMN approval_mode TEXT NOT NULL DEFAULT 'device'")
    replaced = {('/api/commerce/cli/start','POST'), ('/api/commerce/cli/approve','POST'), ('/cli/authorize','GET')}
    app.router.routes[:] = [route for route in app.router.routes if not any(
        (getattr(route,'path',''),method) in replaced for method in getattr(route,'methods',set()))]

    @app.post('/api/commerce/cli/start')
    def start(body: StartInput, request: Request):
        if not dbs.limit('cli:start:' + (request.client.host if request.client else 'unknown'),12,600):
            raise HTTPException(429,'Too many authorization attempts')
        request_id, expires = secrets.token_urlsafe(32), time.time()+300
        code = '-'.join(str(secrets.randbelow(10**4)).zfill(4) for _ in range(2)) if body.approval_mode == 'device' else None
        with dbs.db() as db:
            db.execute('INSERT INTO cli_authorizations(id,challenge,state_hash,exchange_hash,approval_mode,expires,created) VALUES(?,?,?,?,?,?,?)',
                       (digest(request_id),body.challenge,digest(body.state),digest(code) if code else None,body.approval_mode,expires,time.time()))
        result = {'request_id':request_id,'authorization_url':state.public_url+'/cli/authorize?request='+request_id,
                  'approval_mode':body.approval_mode,'expires_at':expires,'interval':2}
        if code: result['user_code'] = code
        return result

    @app.get('/cli/authorize', response_class=HTMLResponse)
    def page(request: str):
        if not re.fullmatch(r'[A-Za-z0-9_-]{32,128}',request):
            raise HTTPException(404,'Unknown authorization request')
        with dbs.db() as db:
            row = db.execute('SELECT expires,consumed,approval_mode FROM cli_authorizations WHERE id=?',(digest(request),)).fetchone()
        if not row or row['expires']<time.time() or row['consumed']:
            raise HTTPException(410,'Authorization expired')
        template = (Path(__file__).parent/'cli_authorize.html').read_text()
        return HTMLResponse(template.replace('__AUTERIC_REQUEST_ID__',request)
                            .replace('__APPROVAL_MODE__',row['approval_mode'])
                            .replace('__REGISTRATION_ENABLED__','true' if state.development else 'false')
                            .replace('__LOCAL_DEVELOPMENT__','true' if state.development else 'false'),
                            headers={'Cache-Control':'no-store'})

    @app.post('/api/commerce/cli/approve')
    def approve(body: dict, actor=Depends(state.user_dependency)):
        request_id = body.get('request_id','')
        if not isinstance(request_id,str) or not re.fullmatch(r'[A-Za-z0-9_-]{32,128}',request_id):
            raise HTTPException(422,'Invalid authorization request')
        if not dbs.limit('cli:approve:'+digest(request_id),5,300):
            raise HTTPException(429,'Too many authorization attempts; start again')
        with dbs.db() as db:
            row = db.execute('SELECT approval_mode,exchange_hash FROM cli_authorizations WHERE id=?',(digest(request_id),)).fetchone()
            if not row: raise HTTPException(403,'Authorization does not exist or expired')
            if row['approval_mode'] == 'device':
                code = body.get('user_code','')
                if not isinstance(code,str) or not re.fullmatch(r'[0-9]{4}-[0-9]{4}',code):
                    raise HTTPException(422,'Enter the code shown in your terminal')
                if not secrets.compare_digest(row['exchange_hash'] or '',digest(code)):
                    raise HTTPException(403,'Code does not match, or authorization expired')
            changed = db.execute('UPDATE cli_authorizations SET user_id=? WHERE id=? AND user_id IS NULL AND consumed IS NULL AND expires>?',
                                 (actor['id'],digest(request_id),time.time())).rowcount
            if not changed: raise HTTPException(403,'Authorization expired or already approved')
        dbs.event(actor['org'],None,actor['id'],'cli.authorization.approved')
        return {'approved':True}
    app.openapi_schema = None
